import tabula
import pandas as pd

# Caminho do arquivo PDF
pdf_path = 'CorretorCompleto.pdf'

lista_tabelas = tabula.read_pdf(pdf_path, pages="1")
print(len(lista_tabelas))

for tabela in lista_tabelas:
    tabela.columns = tabela.iloc[0]
    print(tabela)



# # Função para extrair tabelas do PDF
# def extrair_tabelas(pdf_path, paginas=1):
#     # Lê as tabelas nas primeiras páginas do PDF
#     tabelas = tabula.read_pdf(pdf_path, pages=f'1-{paginas}', multiple_tables=True, guess=True)
    
#     return tabelas

# # Função para tratar as tabelas, identificando a primeira coluna como índice
# def tratar_tabelas(tabelas):
#     tabelas_tratadas = []
#     for tabela in tabelas:
#         # Ajuste o DataFrame para que a primeira coluna seja o índice
#         tabela.set_index(tabela.columns[0], inplace=True)
#         tabelas_tratadas.append(tabela)
    
#     return tabelas_tratadas



# # Extrair as tabelas (neste exemplo, das 5 primeiras páginas)
# tabelas = extrair_tabelas(pdf_path, paginas=3)

# # Tratar as tabelas, definindo a primeira coluna como índice
# tabelas_tratadas = tratar_tabelas(tabelas)

# # Exibir as tabelas tratadas
# for i, tabela in enumerate(tabelas_tratadas):
#     print(f"Tabela {i + 1}")
#     print(tabela)
#     print("\n")

# # Salvar as tabelas tratadas em arquivos CSV, caso deseje
# for i, tabela in enumerate(tabelas_tratadas):
#     tabela.to_csv(f"tabela_{i + 1}.csv")