import json

# Dados da tabela em formato JSON
planos_json = '''
{
  "Compacto": {
    "De 0 a 18 anos": 425.00,
    "De 19 a 23 anos": 520.21,
    "De 24 a 28 anos": 651.36,
    "De 29 a 33 anos": 719.79,
    "De 34 a 38 anos": 766.66,
    "De 39 a 43 anos": 889.32,
    "De 44 a 48 anos": 1063.10,
    "De 49 a 53 anos": 1275.01,
    "De 54 a 58 anos": 1513.74,
    "59 anos ou mais": 2550.02
  },
  "Efetivo": {
    "De 0 a 18 anos": 476.98,
    "De 19 a 23 anos": 583.82,
    "De 24 a 28 anos": 731.03,
    "De 29 a 33 anos": 807.83,
    "De 34 a 38 anos": 860.43,
    "De 39 a 43 anos": 998.08,
    "De 44 a 48 anos": 1193.12,
    "De 49 a 53 anos": 1430.94,
    "De 54 a 58 anos": 1698.87,
    "59 anos ou mais": 2861.90
  },
  "Completo": {
    "De 0 a 18 anos": 567.06,
    "De 19 a 23 anos": 694.07,
    "De 24 a 28 anos": 869.07,
    "De 29 a 33 anos": 960.37,
    "De 34 a 38 anos": 1022.91,
    "De 39 a 43 anos": 1186.56,
    "De 44 a 48 anos": 1418.42,
    "De 49 a 53 anos": 1701.16,
    "De 54 a 58 anos": 2019.67,
    "59 anos ou mais": 3402.31
  },
  "Superior": {
    "De 0 a 18 anos": 631.45,
    "De 19 a 23 anos": 772.90,
    "De 24 a 28 anos": 967.77,
    "De 29 a 33 anos": 1069.44,
    "De 34 a 38 anos": 1143.19,
    "De 39 a 43 anos": 1321.32,
    "De 44 a 48 anos": 1597.51,
    "De 49 a 53 anos": 1894.36,
    "De 54 a 58 anos": 2249.05,
    "59 anos ou mais": 3788.72
  },
  "Superior Plus": {
    "De 0 a 18 anos": 707.10,
    "De 19 a 23 anos": 865.50,
    "De 24 a 28 anos": 1083.70,
    "De 29 a 33 anos": 1197.55,
    "De 34 a 38 anos": 1275.54,
    "De 39 a 43 anos": 1479.61,
    "De 44 a 48 anos": 1768.75,
    "De 49 a 53 anos": 2121.31,
    "De 54 a 58 anos": 2518.49,
    "59 anos ou mais": 4242.61
  },
  "Sênior": {
    "De 0 a 18 anos": 1340.07,
    "De 19 a 23 anos": 1640.23,
    "De 24 a 28 anos": 2053.79,
    "De 29 a 33 anos": 2269.55,
    "De 34 a 38 anos": 2417.34,
    "De 39 a 43 anos": 2804.08,
    "De 44 a 48 anos": 3352.04,
    "De 49 a 53 anos": 4020.19,
    "De 54 a 58 anos": 4772.91,
    "59 anos ou mais": 8040.38
  }
}
'''

# Carregar o JSON
planos = json.loads(planos_json)

# Função para obter as informações por faixa etária
def obter_quantidades_por_faixa():
    faixas = [
        "De 0 a 18 anos", "De 19 a 23 anos", "De 24 a 28 anos",
        "De 29 a 33 anos", "De 34 a 38 anos", "De 39 a 43 anos",
        "De 44 a 48 anos", "De 49 a 53 anos", "De 54 a 58 anos", "59 anos ou mais"
    ]
    quantidades = {}
    for faixa in faixas:
        while True:
            try:
                quantidade = int(input(f"Digite a quantidade de funcionários na faixa '{faixa}': "))
                if quantidade < 0:
                    print("A quantidade não pode ser negativa. Tente novamente.")
                    continue
                quantidades[faixa] = quantidade
                break
            except ValueError:
                print("Por favor, insira um número válido.")
    return quantidades

# Função para calcular o custo total por plano
def calcular_custo_total(planos, quantidades):
    custos_totais = {}
    for plano, precos in planos.items():
        total = sum(quantidades[faixa] * precos[faixa] for faixa in quantidades)
        custos_totais[plano] = total
    return custos_totais

# Solicitar o número total de funcionários e as distribuições por faixa etária
try:
    print("Cotação para plano empresarial:\n")
    total_funcionarios = int(input("Digite o número total de funcionários: "))
    if total_funcionarios <= 0:
        print("O número de funcionários deve ser maior que zero.")
    else:
        print("\nAgora, informe a quantidade de funcionários em cada faixa etária.")
        quantidades = obter_quantidades_por_faixa()

        # Verificar se a soma das quantidades corresponde ao total de funcionários
        if sum(quantidades.values()) != total_funcionarios:
            print("\nA soma das quantidades informadas não corresponde ao total de funcionários. Verifique e tente novamente.")
        else:
            # Calcular os custos totais para cada plano
            custos_totais = calcular_custo_total(planos, quantidades)
            plano_mais_barato = min(custos_totais, key=custos_totais.get)
            menor_custo = custos_totais[plano_mais_barato]

            # Exibir resultados
            print("\nCustos totais por plano:")
            for plano, custo in custos_totais.items():
                print(f"{plano}: R$ {custo:.2f}")

            print(f"\nO plano mais indicado é o '{plano_mais_barato}' com custo total de R$ {menor_custo:.2f}")
except ValueError:
    print("Por favor, insira um número válido.")
