<style>
    .tab .custom-label {
        font-size: 2.2rem;
        letter-spacing: -.35px;
        font-weight: 900;
        color: #742fe1;
        display: block;
    }

    .tab .custom-border-select {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        border: none;
        outline: 0;
        background: 0 0;
        border-bottom: 3px solid #c5c5c5;
        font-size: 2.8rem;
        letter-spacing: -.35px;
        color: #742fe1;
        margin-top: 1.5rem;
        padding: 0 1.5rem;
        width: 100%;
        -moz-text-align-last: center;
        text-align-last: center;
    }

    .tab .button-range {
        width: 48px;
        height: 48px;
        line-height: 1;
        display: -webkit-inline-box;
        display: -ms-inline-flexbox;
        display: inline-flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        justify-content: center;
        border-radius: 10px;
        background-color: #ff8a00;
        border: none;
        outline: 0;
        font-size: 48px;
        color: #742fe1;
        cursor: pointer;
    }

    .tab .slider {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        height: 4px;
        border-radius: 5px;
        background: #c5c5c5;
        outline: 0;
        -webkit-transition: .2s;
        -webkit-transition: opacity .2s;
        -o-transition: opacity .2s;
        transition: opacity .2s;
        -webkit-box-flex: 1;
        -ms-flex: 1;
        flex: 1;
    }

    .tab .wrapper-gray {
        border-radius: 10px;
        background-color: #e2e2e2;
        padding: 1.9rem 3rem;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        justify-content: center;
        font-size: 2.4rem;
    }
</style>

<div class="col-md-5 text-center">
    <div class="wrapper-ranger-system mt-5 mt-md-0">
        <label for="renda_bruta" class="custom-label">
            Selecione o valor
        </label>
        <div name="renda_bruta" id="renda_bruta" class="custom-border-select">
            <span class="output-renda">
                0.000,00
            </span>
        </div>
        <div class="d-flex align-items-center mt-5">
            <button class="button-range decrease-range">
                -
            </button>
            <input type="range" step="1" min="1" max="10000" value="1" class="slider">
            <button class="button-range increase-range">
                +
            </button>
        </div>
        <div class="mt-5">
            <label for="input-range-value" class="label-2">Para um valor maior ou mais
                específico, digite aqui:</label>
        </div>

        <div class="wrapper-gray mt-5">
            R$ <input type="number" inputmode="numeric" class="input-number-text" name="renda" value="00,00" placeholder="00,00" data-error-message="Selecione ou digite a sua renda. Essa informação é referente a renda bruta familiar, você pode somar a sua renda com a de seus familiares, como cônjuge, pai ou mãe. É com base nesse valor que informaremos o número de parcelas, o quanto será financiado e o tempo de pagamento.">
        </div>
    </div>
</div>