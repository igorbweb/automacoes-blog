import os
import json
import requests
from bs4 import BeautifulSoup

# Função para converter a data para o formato WordPress
def converter_data(data_str):
    meses = {
        "janeiro": "01", "fevereiro": "02", "março": "03", "abril": "04", "maio": "05",
        "junho": "06", "julho": "07", "agosto": "08", "setembro": "09", "outubro": "10",
        "novembro": "11", "dezembro": "12"
    }
    try:
        partes = data_str.split(' ')
        dia = partes[0]
        mes = partes[2].replace(",", "")
        ano = partes[4][:4]
        return f"{ano}-{meses[mes]}-{dia} 14:00:00"
    except Exception as e:
        print(f"Erro ao converter data '{data_str}': {e}")
        return None

# Função para acessar páginas internas e obter o src do iframe
def get_iframe_src(post_url):
    response = requests.get(post_url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.content, "html.parser")
        iframe = soup.select_one("#content iframe")
        if iframe and iframe.get("src"):
            return iframe["src"]
    print(f"Erro ou iframe não encontrado na URL: {post_url}")
    return None

# Função para crawlear as páginas e armazenar dados em JSON
def scrape_to_json(base_url, output_file, max_pages=10):
    page = 1
    all_data = []  # Lista para armazenar todos os dados

    while page <= max_pages:  # Limita a 10 páginas
        print(f"Acessando página {page}...")
        url = f"{base_url}/page/{page}"
        response = requests.get(url)

        # Verifica se a página existe
        if response.status_code == 404:
            print(f"Página {page} não encontrada (404). Encerrando...")
            break

        soup = BeautifulSoup(response.content, "html.parser")
        posts = soup.find_all("div", class_="postholder")

        # Se não encontrar posts, encerramos o processo
        if not posts:
            print(f"Sem posts na página {page}. Encerrando...")
            break

        for post in posts:
            try:
                # Título
                title_element = post.select_one("a.the-title h4")
                title = title_element.text.strip() if title_element else "Sem título"

                # Imagem principal
                img_element = post.select_one("div.single-thumbnail img")
                img_src = img_element["src"] if img_element and img_element.get("src") else None

                # URL da postagem para obter o iframe
                post_link_element = post.select_one("a.the-title")
                post_url = post_link_element["href"] if post_link_element and post_link_element.get("href") else None

                # Iframe (acessando a URL interna)
                iframe_src = get_iframe_src(post_url) if post_url else None

                # Data
                date_element = post.select_one("a.the-date")
                raw_date = date_element.text.strip() if date_element else "01 de janeiro, 1970"
                formatted_date = converter_data(raw_date)

                # Adiciona os dados ao JSON
                all_data.append({
                    "título": title,
                    "imagem_principal": img_src,
                    "data": formatted_date,
                    "iframe": iframe_src
                })

            except Exception as e:
                print(f"Erro ao processar post: {e}")

        page += 1

    # Salvar os dados em um arquivo JSON
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(all_data, f, ensure_ascii=False, indent=4)
        print(f"Dados salvos em {output_file}")

# URL base e arquivo de saída
base_url = "https://esquerdaonline.com.br/videos"
output_json = "videos_data.json"

# Iniciando o processo com limite de 10 páginas
scrape_to_json(base_url, output_json, max_pages=10)
