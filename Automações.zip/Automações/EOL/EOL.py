import os
import requests
from bs4 import BeautifulSoup

# Função para baixar imagens
def download_image(url, folder):
    if not os.path.exists(folder):
        os.makedirs(folder)
    filename = os.path.join(folder, url.split("/")[-1])
    response = requests.get(url, stream=True)
    if response.status_code == 200:
        with open(filename, "wb") as f:
            for chunk in response.iter_content(1024):
                f.write(chunk)
        print(f"Imagem salva: {filename}")
    else:
        print(f"Erro ao baixar {url}")

# Função para crawlear as páginas
def scrape_images(base_url, folder):
    page = 1
    while True:
        print(f"Acessando página {page}...")
        url = f"{base_url}/page/{page}"
        response = requests.get(url)
        if response.status_code != 200:
            print(f"Erro ao acessar {url}. Encerrando...")
            break

        soup = BeautifulSoup(response.content, "html.parser")
        divs = soup.find_all("div", class_="each-colunista")
        if not divs:
            print(f"Sem divs com a classe 'each-colunista' na página {page}. Encerrando...")
            break

        for div in divs:
            img = div.find("img")  # Procura a imagem dentro da div
            if img and img.get("src"):
                download_image(img["src"], folder)

        page += 1

# URL base e pasta de destino
base_url = "https://esquerdaonline.com.br/colunistas"
destination_folder = "imagens_colunistas"

# Iniciando o processo
scrape_images(base_url, destination_folder)